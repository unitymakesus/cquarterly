<div class="notification-message warning-notice inline-message invalid-licence">
	<?php echo $this->get_licence_status_message(); ?>
</div>